<?php
// register.php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/config/database.php';

if (isset($_SESSION['user_id'])) {
    header("Location: /user/dashboard.php");
    exit();
}

$errors = [];
$fullName = '';
$username = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $errors[] = 'Invalid request token. Please refresh and try again.';
    }

    $fullName = trim($_POST['full_name'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';

    if (empty($fullName)) $errors[] = 'Full Name is required.';
    if (empty($username)) $errors[] = 'Username is required.';
    if (!preg_match('/^[a-zA-Z0-9_]{3,30}$/', $username)) {
        $errors[] = 'Username must be 3-30 characters and contain only letters, numbers, and underscores.';
    }
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'A valid email address is required.';
    }
    if (empty($password)) $errors[] = 'Password is required.';
    if (strlen($password) < 6) $errors[] = 'Password must be at least 6 characters long.';
    if ($password !== $confirmPassword) {
        $errors[] = 'Passwords do not match.';
    }

    if (empty($errors)) {
        $pdo = getDBConnection();
        // Check uniqueness
        $stmt = $pdo->prepare("SELECT user_id FROM users WHERE username = ? OR email = ?");
        $stmt->execute([$username, $email]);
        if ($stmt->fetch()) {
            $errors[] = 'Username or Email is already registered.';
        } else {
            $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
            $insStmt = $pdo->prepare("INSERT INTO users (full_name, username, email, password, status) VALUES (?, ?, ?, ?, 'active')");
            if ($insStmt->execute([$fullName, $username, $email, $hashedPassword])) {
                $userId = $pdo->lastInsertId();
                $_SESSION['user_id'] = $userId;
                $_SESSION['username'] = $username;

                // Create initial portfolio record
                getOrCreateUserPortfolio($userId, $pdo);

                setFlash('success', 'Registration successful! Welcome to Portfolio Forge.');
                header("Location: /user/dashboard.php");
                exit();
            } else {
                $errors[] = 'Failed to register user. Please try again.';
            }
        }
    }
}

$pageTitle = 'Register - Portfolio Forge';
require_once __DIR__ . '/includes/header.php';
?>

<div class="auth-container">
    <div class="auth-header">
        <h2>Create Account</h2>
        <p>Build and showcase your professional portfolio</p>
    </div>

    <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
            <ul style="padding-left: 1.2rem; margin: 0;">
                <?php foreach ($errors as $err): ?>
                    <li><?= sanitize($err) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="register.php" method="POST" class="auth-form">
        <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">

        <div class="form-group">
            <label for="full_name">Full Name *</label>
            <input type="text" id="full_name" name="full_name" class="form-control" value="<?= sanitize($fullName) ?>" required>
        </div>

        <div class="form-group">
            <label for="username">Username *</label>
            <input type="text" id="username" name="username" class="form-control" value="<?= sanitize($username) ?>" required>
            <span class="form-help">Unique identifier for your account</span>
        </div>

        <div class="form-group">
            <label for="email">Email Address *</label>
            <input type="email" id="email" name="email" class="form-control" value="<?= sanitize($email) ?>" required>
        </div>

        <div class="form-group">
            <label for="password">Password *</label>
            <input type="password" id="password" name="password" class="form-control" required minlength="6">
        </div>

        <div class="form-group">
            <label for="confirm_password">Confirm Password *</label>
            <input type="password" id="confirm_password" name="confirm_password" class="form-control" required>
        </div>

        <button type="submit" class="nav-btn btn-primary" style="width: 100%; margin-top: 1rem; padding: 0.8rem;">Register Account</button>
    </form>

    <div style="text-align: center; margin-top: 1.5rem; font-size: 0.9rem; color: var(--text-secondary);">
        Already have an account? <a href="/login.php" style="color: var(--primary-color); font-weight: 600; text-decoration: none;">Login here</a>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
