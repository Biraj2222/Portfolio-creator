<?php
// tests/verify_app.php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

echo "=== PORTFOLIO FORGE AUTOMATED SYSTEM VERIFICATION ===\n\n";

$pdo = getDBConnection();
$passed = 0;
$failed = 0;

function assertTest($condition, $testName) {
    global $passed, $failed;
    if ($condition) {
        echo "✅ PASS: {$testName}\n";
        $passed++;
    } else {
        echo "❌ FAIL: {$testName}\n";
        $failed++;
    }
}

// 1. Test Database Tables Exist
$tables = ['users', 'admins', 'portfolios', 'portfolio_sections', 'resume', 'templates', 'portfolio_visits'];
foreach ($tables as $t) {
    $stmt = $pdo->query("SHOW TABLES LIKE '{$t}'");
    assertTest($stmt->rowCount() > 0, "Table '{$t}' exists in database");
}

// 2. Test User Registration & Password Hashing
$testUsername = 'testuser_' . time();
$testEmail = 'test_' . time() . '@example.com';
$testPassword = 'securePassword123';
$hashed = password_hash($testPassword, PASSWORD_BCRYPT);

$insUser = $pdo->prepare("INSERT INTO users (full_name, username, email, password, status) VALUES ('Test User', ?, ?, ?, 'active')");
$insUser->execute([$testUsername, $testEmail, $hashed]);
$userId = $pdo->lastInsertId();

assertTest($userId > 0, "Registered test user ID: {$userId}");
assertTest(password_verify($testPassword, $hashed), "Password hashing and verification functioning");

// 3. Test Portfolio Creation & Single Portfolio Constraint
$portfolio = getOrCreateUserPortfolio($userId, $pdo);
assertTest(!empty($portfolio), "Portfolio created automatically for user");

$portfolio2 = getOrCreateUserPortfolio($userId, $pdo);
assertTest($portfolio['portfolio_id'] === $portfolio2['portfolio_id'], "Strict 1:1 Portfolio constraint enforced");

// 4. Test Portfolio Sections CRUD
$secStmt = $pdo->prepare("SELECT COUNT(*) FROM portfolio_sections WHERE portfolio_id = ?");
$secStmt->execute([$portfolio['portfolio_id']]);
assertTest($secStmt->fetchColumn() >= 6, "Default core sections created for portfolio");

// Update section
$upSec = $pdo->prepare("UPDATE portfolio_sections SET title = 'Updated Section Title', content = ? WHERE portfolio_id = ? AND section_type = 'about'");
$upSec->execute([json_encode(['text' => 'Updated about text content.']), $portfolio['portfolio_id']]);

$checkSec = $pdo->prepare("SELECT title FROM portfolio_sections WHERE portfolio_id = ? AND section_type = 'about'");
$checkSec->execute([$portfolio['portfolio_id']]);
assertTest($checkSec->fetchColumn() === 'Updated Section Title', "Section content update persisted");

// 5. Test Template Switching without data loss
$upTpl = $pdo->prepare("UPDATE portfolios SET template_id = 3 WHERE portfolio_id = ?");
$upTpl->execute([$portfolio['portfolio_id']]);

$checkTpl = $pdo->prepare("SELECT template_id FROM portfolios WHERE portfolio_id = ?");
$checkTpl->execute([$portfolio['portfolio_id']]);
assertTest($checkTpl->fetchColumn() == 3, "Switched template to Professional without altering sections data");

// 6. Test Non-AI Resume Parsing Function
$sampleText = "
Jane Doe
Email: jane.doe@example.com
Phone: (555) 123-4567

SUMMARY
Experienced software engineer with a strong foundation in PHP, MySQL, and JavaScript.

TECHNICAL SKILLS
PHP, MySQL, JavaScript, HTML5, CSS3, Git

EXPERIENCE
Software Engineer at Tech Corp (2021-Present)
Developed scalable web applications and REST APIs.

EDUCATION
BCA in Computer Applications - State University
";

$parsedData = parseResumeText($sampleText);
assertTest($parsedData['email'] === 'jane.doe@example.com', "Parser extracted email correctly");
assertTest($parsedData['phone'] === '(555) 123-4567', "Parser extracted phone correctly");
assertTest(in_array('PHP', $parsedData['skills']), "Parser extracted skills array correctly");

// 7. Test Public Visit Counter Increments & Owner Preview Exclusion
$slug = $portfolio['portfolio_slug'];

// Publish portfolio
$pdo->prepare("UPDATE portfolios SET status = 'published' WHERE portfolio_id = ?")->execute([$portfolio['portfolio_id']]);

$vCountBefore = $pdo->prepare("SELECT COUNT(*) FROM portfolio_visits WHERE portfolio_id = ?");
$vCountBefore->execute([$portfolio['portfolio_id']]);
$c1 = $vCountBefore->fetchColumn();

// Record 2 public visits
$pdo->prepare("INSERT INTO portfolio_visits (portfolio_id) VALUES (?)")->execute([$portfolio['portfolio_id']]);
$pdo->prepare("INSERT INTO portfolio_visits (portfolio_id) VALUES (?)")->execute([$portfolio['portfolio_id']]);

$vCountAfter = $pdo->prepare("SELECT COUNT(*) FROM portfolio_visits WHERE portfolio_id = ?");
$vCountAfter->execute([$portfolio['portfolio_id']]);
$c2 = $vCountAfter->fetchColumn();

assertTest($c2 == ($c1 + 2), "Public visit counter correctly incremented by 2");

// 8. Test Admin Deactivation Blocks Login / Public Access
$deact = $pdo->prepare("UPDATE users SET status = 'inactive' WHERE user_id = ?");
$deact->execute([$userId]);

$chDeact = $pdo->prepare("SELECT status FROM users WHERE user_id = ?");
$chDeact->execute([$userId]);
assertTest($chDeact->fetchColumn() === 'inactive', "Admin user account deactivation state updated");

// Cleanup test user
$pdo->prepare("DELETE FROM users WHERE user_id = ?")->execute([$userId]);

echo "\n=== SUMMARY ===";
echo "\nTotal Passed: {$passed}";
echo "\nTotal Failed: {$failed}\n\n";

if ($failed === 0) {
    echo "🎉 ALL BACKEND VERIFICATION TESTS PASSED SUCCESSFULLY!\n";
    exit(0);
} else {
    echo "⚠️ SOME TESTS FAILED.\n";
    exit(1);
}
