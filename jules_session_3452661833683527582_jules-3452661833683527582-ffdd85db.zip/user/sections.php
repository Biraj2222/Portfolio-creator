<?php
// user/sections.php
require_once __DIR__ . '/../includes/auth.php';
$user = requireLogin();

$pdo = getDBConnection();
$portfolio = getOrCreateUserPortfolio($user['user_id'], $pdo);
$pId = $portfolio['portfolio_id'];

// Fetch all existing sections
$sStmt = $pdo->prepare("SELECT * FROM portfolio_sections WHERE portfolio_id = ? ORDER BY display_order ASC, section_id ASC");
$sStmt->execute([$pId]);
$sections = $sStmt->fetchAll();

// Handle Form Submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        setFlash('danger', 'Invalid CSRF token.');
        header("Location: /user/sections.php");
        exit();
    }

    $action = $_POST['action'] ?? '';

    if ($action === 'save_section') {
        $sectionId = (int)($_POST['section_id'] ?? 0);
        $sectionType = trim($_POST['section_type'] ?? 'about');
        $title = trim($_POST['title'] ?? '');
        $displayOrder = (int)($_POST['display_order'] ?? 1);
        $isVisible = isset($_POST['is_visible']) ? 1 : 0;
        $contentRaw = $_POST['content'] ?? '';

        // Decode json or format array properly
        if (is_array($contentRaw)) {
            $contentJson = json_encode($contentRaw);
        } else {
            // Check if string is valid JSON or array text
            $decoded = json_decode($contentRaw, true);
            if (json_last_error() === JSON_ERROR_NONE) {
                $contentJson = $contentRaw;
            } else {
                $contentJson = json_encode(['text' => $contentRaw]);
            }
        }

        if ($sectionId > 0) {
            $uStmt = $pdo->prepare("UPDATE portfolio_sections SET section_type = ?, title = ?, content = ?, display_order = ?, is_visible = ? WHERE section_id = ? AND portfolio_id = ?");
            $uStmt->execute([$sectionType, $title, $contentJson, $displayOrder, $isVisible, $sectionId, $pId]);
            setFlash('success', "Section '{$title}' updated successfully.");
        } else {
            $iStmt = $pdo->prepare("INSERT INTO portfolio_sections (portfolio_id, section_type, title, content, display_order, is_visible) VALUES (?, ?, ?, ?, ?, ?)");
            $iStmt->execute([$pId, $sectionType, $title, $contentJson, $displayOrder, $isVisible]);
            setFlash('success', "New section '{$title}' added successfully.");
        }
    } elseif ($action === 'delete_section') {
        $sectionId = (int)($_POST['section_id'] ?? 0);
        $dStmt = $pdo->prepare("DELETE FROM portfolio_sections WHERE section_id = ? AND portfolio_id = ?");
        $dStmt->execute([$sectionId, $pId]);
        setFlash('success', "Section deleted successfully.");
    }

    header("Location: /user/sections.php");
    exit();
}

$pageTitle = 'Portfolio Sections - Portfolio Forge';
$extraCss = 'dashboard.css';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="dashboard-layout">
    <aside class="sidebar">
        <div class="sidebar-heading">User Dashboard</div>
        <ul class="sidebar-menu">
            <li><a href="/user/dashboard.php">📊 Overview</a></li>
            <li><a href="/user/edit-portfolio.php">✏️ Edit Portfolio</a></li>
            <li><a href="/user/sections.php" class="active">🧩 Sections</a></li>
            <li><a href="/user/resume.php">📄 Resume Upload</a></li>
            <li><a href="/user/templates.php">🎨 Templates</a></li>
            <li><a href="/user/statistics.php">📈 Statistics</a></li>
            <li><a href="/user/profile.php">⚙️ Profile Settings</a></li>
        </ul>
    </aside>

    <main class="dashboard-content">
        <div class="content-header">
            <div>
                <h1>Portfolio Sections Manager</h1>
                <p style="color: var(--text-secondary);">Add, edit, or remove core and optional portfolio sections. All manual & extracted data is fully editable.</p>
            </div>
            <button onclick="openSectionModal(0, '', '', '', 1, 1)" class="nav-btn btn-primary">+ Add New Section</button>
        </div>

        <div class="panel-card">
            <h2 class="panel-title" style="margin-bottom: 1rem;">Your Active Sections</h2>

            <?php if (empty($sections)): ?>
                <p style="color: var(--text-secondary);">No sections configured yet. Click "+ Add New Section" to begin.</p>
            <?php else: ?>
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Order</th>
                            <th>Section Title</th>
                            <th>Type</th>
                            <th>Visibility</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($sections as $sec): 
                            $cDecoded = json_decode($sec['content'] ?? '', true) ?? [];
                        ?>
                            <tr>
                                <td><strong><?= (int)$sec['display_order'] ?></strong></td>
                                <td>
                                    <strong><?= sanitize($sec['title']) ?></strong>
                                </td>
                                <td><span class="badge badge-info"><?= sanitize(strtoupper($sec['section_type'])) ?></span></td>
                                <td>
                                    <?php if ($sec['is_visible']): ?>
                                        <span class="badge badge-success">Visible</span>
                                    <?php else: ?>
                                        <span class="badge badge-warning">Hidden</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <button class="nav-btn btn-outline btn-sm" onclick='openSectionModal(<?= $sec["section_id"] ?>, <?= json_encode($sec["section_type"]) ?>, <?= json_encode($sec["title"]) ?>, <?= json_encode($sec["content"]) ?>, <?= $sec["display_order"] ?>, <?= $sec["is_visible"] ?>)'>Edit</button>

                                    <form action="/user/sections.php" method="POST" style="display: inline;" onsubmit="return confirm('Delete this section?');">
                                        <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
                                        <input type="hidden" name="action" value="delete_section">
                                        <input type="hidden" name="section_id" value="<?= $sec['section_id'] ?>">
                                        <button type="submit" class="nav-btn btn-danger btn-sm">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>

        <!-- Section Edit/Add Modal Overlay -->
        <div id="sectionModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 2000; align-items: center; justify-content: center; padding: 1rem;">
            <div style="background: #fff; border-radius: var(--radius-md); max-width: 650px; width: 100%; padding: 2rem; max-height: 90vh; overflow-y: auto;">
                <h2 id="modalHeaderTitle" style="margin-bottom: 1.5rem; color: var(--secondary-color);">Edit Section</h2>

                <form action="/user/sections.php" method="POST">
                    <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
                    <input type="hidden" name="action" value="save_section">
                    <input type="hidden" id="modal_section_id" name="section_id" value="0">

                    <div class="form-group">
                        <label for="modal_title">Section Display Title *</label>
                        <input type="text" id="modal_title" name="title" class="form-control" required placeholder="e.g. Work Experience or Key Projects">
                    </div>

                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                        <div class="form-group">
                            <label for="modal_section_type">Section Type *</label>
                            <select id="modal_section_type" name="section_type" class="form-control" required>
                                <optgroup label="Core Sections">
                                    <option value="about">About Me</option>
                                    <option value="education">Education</option>
                                    <option value="skills">Skills</option>
                                    <option value="projects">Projects</option>
                                    <option value="experience">Experience</option>
                                    <option value="contact">Contact</option>
                                </optgroup>
                                <optgroup label="Optional Sections">
                                    <option value="certifications">Certifications</option>
                                    <option value="achievements">Achievements</option>
                                    <option value="languages">Languages</option>
                                    <option value="activities">Activities</option>
                                    <option value="interests">Interests</option>
                                </optgroup>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="modal_display_order">Display Order</label>
                            <input type="number" id="modal_display_order" name="display_order" class="form-control" value="1" min="1">
                        </div>
                    </div>

                    <div class="form-group" style="display: flex; align-items: center; gap: 0.5rem; margin-top: 0.5rem;">
                        <input type="checkbox" id="modal_is_visible" name="is_visible" value="1" checked>
                        <label for="modal_is_visible" style="margin-bottom: 0;">Visible on Public Portfolio</label>
                    </div>

                    <div class="form-group" style="margin-top: 1rem;">
                        <label for="modal_content">Section Content (JSON or Text Data) *</label>
                        <textarea id="modal_content" name="content" class="form-control" style="min-height: 180px; font-family: monospace; font-size: 0.9rem;" required></textarea>
                        <span class="form-help">Enter text content or valid JSON structure (e.g. array of items). Extracted resume data can be edited or changed freely here.</span>
                    </div>

                    <div style="display: flex; justify-content: flex-end; gap: 1rem; margin-top: 1.5rem;">
                        <button type="button" class="nav-btn btn-outline" onclick="closeSectionModal()">Cancel</button>
                        <button type="submit" class="nav-btn btn-primary">Save Section Data</button>
                    </div>
                </form>
            </div>
        </div>
    </main>
</div>

<script>
function openSectionModal(id, type, title, content, order, visible) {
    document.getElementById('modal_section_id').value = id;
    document.getElementById('modal_title').value = title || '';
    document.getElementById('modal_section_type').value = type || 'about';
    
    // Format JSON prettily if possible
    try {
        var parsed = typeof content === 'string' ? JSON.parse(content) : content;
        document.getElementById('modal_content').value = JSON.stringify(parsed, null, 2);
    } catch(e) {
        document.getElementById('modal_content').value = content || '';
    }

    document.getElementById('modal_display_order').value = order || 1;
    document.getElementById('modal_is_visible').checked = visible == 1;

    document.getElementById('modalHeaderTitle').innerText = id > 0 ? 'Edit Section Data' : 'Add New Section';
    document.getElementById('sectionModal').style.display = 'flex';
}

function closeSectionModal() {
    document.getElementById('sectionModal').style.display = 'none';
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
