<?php
// user/templates.php
require_once __DIR__ . '/../includes/auth.php';
$user = requireLogin();

$pdo = getDBConnection();
$portfolio = getOrCreateUserPortfolio($user['user_id'], $pdo);

// Fetch all active templates
$tStmt = $pdo->query("SELECT * FROM templates WHERE is_active = 1 ORDER BY template_id ASC");
$templates = $tStmt->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        setFlash('danger', 'Invalid CSRF token.');
        header("Location: /user/templates.php");
        exit();
    }

    $templateId = (int)($_POST['template_id'] ?? 1);

    // Verify template exists and is active
    $chStmt = $pdo->prepare("SELECT template_id, template_name FROM templates WHERE template_id = ? AND is_active = 1");
    $chStmt->execute([$templateId]);
    $selectedTemplate = $chStmt->fetch();

    if ($selectedTemplate) {
        $uStmt = $pdo->prepare("UPDATE portfolios SET template_id = ? WHERE portfolio_id = ?");
        $uStmt->execute([$templateId, $portfolio['portfolio_id']]);
        setFlash('success', "Template switched to '" . htmlspecialchars($selectedTemplate['template_name']) . "' without losing any portfolio data.");
    } else {
        setFlash('danger', 'Selected template is invalid or inactive.');
    }

    header("Location: /user/templates.php");
    exit();
}

// Refresh portfolio
$portfolio = getOrCreateUserPortfolio($user['user_id'], $pdo);

$pageTitle = 'Templates - Portfolio Forge';
$extraCss = 'dashboard.css';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="dashboard-layout">
    <aside class="sidebar">
        <div class="sidebar-heading">User Dashboard</div>
        <ul class="sidebar-menu">
            <li><a href="/user/dashboard.php">📊 Overview</a></li>
            <li><a href="/user/edit-portfolio.php">✏️ Edit Portfolio</a></li>
            <li><a href="/user/sections.php">🧩 Sections</a></li>
            <li><a href="/user/resume.php">📄 Resume Upload</a></li>
            <li><a href="/user/templates.php" class="active">🎨 Templates</a></li>
            <li><a href="/user/statistics.php">📈 Statistics</a></li>
            <li><a href="/user/profile.php">⚙️ Profile Settings</a></li>
        </ul>
    </aside>

    <main class="dashboard-content">
        <div class="content-header">
            <div>
                <h1>Choose Your Design Template</h1>
                <p style="color: var(--text-secondary);">Switching templates alters visual layout only. All your portfolio data, sections, and uploads remain completely safe.</p>
            </div>
        </div>

        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 1.5rem;">
            <?php foreach ($templates as $tpl): 
                $isSelected = ($tpl['template_id'] == $portfolio['template_id']);
            ?>
                <div class="panel-card" style="padding: 0; overflow: hidden; display: flex; flex-direction: column; border: <?= $isSelected ? '2px solid var(--primary-color)' : '1px solid var(--border-color)' ?>;">
                    <div style="background-color: #f1f5f9; height: 150px; display: flex; align-items: center; justify-content: center; position: relative;">
                        <span style="font-size: 1.5rem; font-weight: 700; color: var(--secondary-color);"><?= sanitize($tpl['template_name']) ?></span>
                        <?php if ($isSelected): ?>
                            <span class="badge badge-success" style="position: absolute; top: 10px; right: 10px;">Active Template</span>
                        <?php endif; ?>
                    </div>

                    <div style="padding: 1.25rem; flex: 1; display: flex; flex-direction: column;">
                        <h3 style="font-size: 1.1rem; color: var(--secondary-color); margin-bottom: 0.5rem;"><?= sanitize($tpl['template_name']) ?> Layout</h3>
                        <p style="color: var(--text-secondary); font-size: 0.875rem; flex: 1; margin-bottom: 1.25rem; line-height: 1.5;"><?= sanitize($tpl['description']) ?></p>

                        <?php if ($isSelected): ?>
                            <button disabled class="nav-btn btn-outline" style="width: 100%; opacity: 0.7; cursor: default;">Currently Applied</button>
                        <?php else: ?>
                            <form action="/user/templates.php" method="POST">
                                <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
                                <input type="hidden" name="template_id" value="<?= $tpl['template_id'] ?>">
                                <button type="submit" class="nav-btn btn-primary" style="width: 100%;">Select This Template</button>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </main>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
