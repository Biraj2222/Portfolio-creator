# Portfolio Forge

**Portfolio Forge** is a dynamic, database-driven web-based portfolio builder designed for students and professionals across IT and non-IT academic/professional backgrounds. It enables users to create, edit, customize, and publish a professional portfolio website without requiring programming knowledge.

---

## 🌟 Features

- **User Authentication & Session Management**: Secure user registration, password hashing (`password_hash()`), login with username/email, and account profile management.
- **Single Portfolio per User**: Strict 1:1 relationship between registered user and portfolio.
- **Non-AI Resume Extraction**: Upload PDF resumes and automatically extract readable text (via `pdftotext` with regex fallback) to pre-fill portfolio sections.
- **Fully Editable Data**: Manual and extracted data become standard editable portfolio fields after saving. Users can add missing data, edit existing details, or delete inaccurate information.
- **Five General-Purpose Templates**: Modern, Minimal, Professional, Creative, and Classic layouts differentiated purely by visual presentation.
- **Seamless Template Switching**: Switch between templates dynamically without losing any portfolio data or uploaded resumes.
- **Flexible Sections Management**: Support for core sections (About, Education, Skills, Projects, Experience, Contact) and optional sections (Certifications, Achievements, Languages, Activities, Interests) with customizable visibility and display ordering.
- **Personalized Portfolio URLs**: Public access via clean slug routes (e.g. `/portfolio/john-doe`).
- **Portfolio View Analytics**: Real-time view tracking (`portfolio_visits`) for public visits while excluding owner previews.
- **Administrator Portal**: Admin dashboard to manage user account activation/deactivation (preserving data), template availability, and view system metrics. Admins cannot edit user portfolio content.

---

## 🛠️ Technology Stack

- **Frontend**: HTML5, CSS3 (Custom CSS, strictly no Bootstrap or external CSS frameworks), Vanilla JavaScript
- **Backend**: PHP 8+
- **Database**: MySQL / MariaDB
- **Development Environment**: XAMPP / WAMP / LAMP

---

## 📁 Folder Structure

```
/portfolio-forge
│
├── /admin
│   ├── dashboard.php      # Admin analytics dashboard
│   ├── login.php          # Admin authentication
│   ├── logout.php         # Admin session destruction
│   ├── templates.php      # Admin template manager
│   └── users.php          # Admin user account management
│
├── /assets
│   ├── /css
│   │   ├── dashboard.css  # Dashboard layouts and tables
│   │   ├── style.css      # Core global styles and navbar
│   │   └── templates.css  # Portfolio templates styles
│   └── /images
│
├── /config
│   └── database.php       # PDO MySQL database connection
│
├── /includes
│   ├── admin-auth.php     # Admin session guard
│   ├── auth.php           # User session guard & active account check
│   ├── footer.php         # Layout footer
│   ├── functions.php      # PDF parser, file uploads, slug generator, CSRF
│   └── header.php         # Layout header & flash alerts
│
├── /portfolio
│   └── view.php           # Public portfolio router & view recorder
│
├── /templates
│   ├── /classic           # Classic layout renderer
│   ├── /creative          # Creative layout renderer
│   ├── /minimal           # Minimal layout renderer
│   ├── /modern            # Modern layout renderer
│   └── /professional      # Professional layout renderer
│
├── /tests
│   └── verify_app.php     # Automated test suite
│
├── /uploads
│   ├── /profiles          # Profile picture uploads
│   └── /resumes           # Resume PDF uploads
│
├── .htaccess              # Clean URL rewriting
├── database.sql           # Schema DDL & seed data
├── index.php              # Public landing page
├── login.php              # User login page
├── logout.php             # User logout
├── register.php           # User registration page
└── README.md              # Project documentation
```

---

## 🚀 Setup & Installation Instructions (XAMPP)

1. **Clone or Extract Project**:
   Place the project folder in your XAMPP `htdocs` directory (e.g., `C:/xampp/htdocs/portfolio-forge`).

2. **Database Configuration**:
   - Open **phpMyAdmin** (`http://localhost/phpmyadmin`).
   - Create a new database named `portfolio_forge`.
   - Import `database.sql` into `portfolio_forge`.
   - Alternatively, execute via MySQL command line:
     ```bash
     mysql -u root -p portfolio_forge < database.sql
     ```

3. **Database Connection Credentials**:
   Verify or update database credentials in `config/database.php`:
   ```php
   define('DB_HOST', 'localhost');
   define('DB_USER', 'forge_user'); // or 'root'
   define('DB_PASS', 'forge_pass'); // or ''
   define('DB_NAME', 'portfolio_forge');
   ```

4. **Default Credentials**:
   - **Default Admin Account**:
     - **Username**: `admin`
     - **Password**: `admin123`

5. **Run Application**:
   - Start Apache and MySQL in XAMPP Control Panel.
   - Access the landing page at: `http://localhost/portfolio-forge/` or `http://localhost:8000/`.

---

## 🧪 Testing

To run the automated backend test suite:

```bash
php tests/verify_app.php
```

The test suite automatically tests database schema integrity, user registration, password verification, portfolio 1:1 constraints, section CRUD, template switching without data loss, non-AI resume extraction parser, view count incrementation, and admin user deactivation logic.

---

## 🔒 Security Measures

- **Password Protection**: Passwords securely hashed with `password_hash()` and verified using `password_verify()`.
- **Prepared Statements**: All database operations use PDO prepared statements to protect against SQL Injection.
- **CSRF Token Validation**: Form submissions utilize session-based CSRF tokens.
- **File Upload Security**: Strict MIME type validation, file extension checks, file size limits, and randomized filename generation.
- **Data Privacy & Isolation**: Users can only manage their own portfolio data. Deactivated users are blocked from logging in, and their published portfolios are automatically hidden.
