<?php
// logout.php
require_once __DIR__ . '/includes/functions.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

unset($_SESSION['user_id']);
unset($_SESSION['username']);

setFlash('info', 'You have been logged out successfully.');
header("Location: /login.php");
exit();
