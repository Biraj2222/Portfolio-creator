<?php
// admin/login.php
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../config/database.php';

if (isset($_SESSION['admin_id'])) {
    header("Location: /admin/dashboard.php");
    exit();
}

$errors = [];
$username = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $errors[] = 'Invalid request token.';
    }

    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($username)) $errors[] = 'Admin username is required.';
    if (empty($password)) $errors[] = 'Password is required.';

    if (empty($errors)) {
        $pdo = getDBConnection();
        $stmt = $pdo->prepare("SELECT admin_id, username, email, password FROM admins WHERE username = ? OR email = ?");
        $stmt->execute([$username, $username]);
        $admin = $stmt->fetch();

        if ($admin && password_verify($password, $admin['password'])) {
            $_SESSION['admin_id'] = $admin['admin_id'];
            $_SESSION['admin_username'] = $admin['username'];

            setFlash('success', 'Admin login successful.');
            header("Location: /admin/dashboard.php");
            exit();
        } else {
            $errors[] = 'Invalid admin credentials.';
        }
    }
}

$pageTitle = 'Admin Portal Login - Portfolio Forge';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="auth-container">
    <div class="auth-header">
        <h2>Administrator Portal</h2>
        <p>System management and platform oversight</p>
    </div>

    <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
            <ul style="padding-left: 1.2rem; margin: 0;">
                <?php foreach ($errors as $err): ?>
                    <li><?= sanitize($err) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="/admin/login.php" method="POST" class="auth-form">
        <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">

        <div class="form-group">
            <label for="username">Admin Username or Email *</label>
            <input type="text" id="username" name="username" class="form-control" value="<?= sanitize($username) ?>" required autofocus>
        </div>

        <div class="form-group">
            <label for="password">Password *</label>
            <input type="password" id="password" name="password" class="form-control" required>
        </div>

        <button type="submit" class="nav-btn btn-secondary" style="width: 100%; margin-top: 1rem; padding: 0.8rem;">Log In to Admin Portal</button>
    </form>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
