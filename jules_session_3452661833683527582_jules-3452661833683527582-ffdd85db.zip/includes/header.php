<?php
// includes/header.php
require_once __DIR__ . '/functions.php';

$currentUser = isset($_SESSION['user_id']) ? getCurrentUser() : null;
$isAdmin = isset($_SESSION['admin_id']);
$pageTitle = $pageTitle ?? 'Portfolio Forge - Dynamic Portfolio Builder';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= sanitize($pageTitle) ?></title>
    <link rel="stylesheet" href="/assets/css/style.css">
    <?php if (isset($extraCss)): ?>
        <link rel="stylesheet" href="/assets/css/<?= sanitize($extraCss) ?>">
    <?php endif; ?>
</head>
<body>
    <header class="navbar-header">
        <div class="nav-container">
            <a href="/" class="brand-logo">
                <span class="logo-icon">⚡</span> Portfolio Forge
            </a>
            <nav class="main-nav">
                <a href="/#features">Features</a>
                <a href="/#how-it-works">How It Works</a>
                <a href="/#templates">Templates</a>
                <?php if ($currentUser): ?>
                    <a href="/user/dashboard.php" class="nav-btn btn-secondary">Dashboard</a>
                    <a href="/logout.php" class="nav-btn btn-outline">Logout</a>
                <?php elseif ($isAdmin): ?>
                    <a href="/admin/dashboard.php" class="nav-btn btn-secondary">Admin Panel</a>
                    <a href="/admin/logout.php" class="nav-btn btn-outline">Logout</a>
                <?php else: ?>
                    <a href="/login.php" class="nav-btn btn-outline">Login</a>
                    <a href="/register.php" class="nav-btn btn-primary">Get Started</a>
                <?php endif; ?>
            </nav>
        </div>
    </header>
    <main class="main-wrapper">
        <div class="flash-messages-container">
            <?php displayFlash(); ?>
        </div>
