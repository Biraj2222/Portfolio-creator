<?php
// portfolio/view.php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

$slug = trim($_GET['slug'] ?? '');
$isPreview = isset($_GET['is_preview']) && $_GET['is_preview'] === true;

if (empty($slug)) {
    http_response_code(404);
    die("<h2 style='text-align:center; margin-top: 3rem; color: #334155;'>Portfolio Slug Not Specified</h2>");
}

$pdo = getDBConnection();

// Fetch portfolio, template, and user
$pStmt = $pdo->prepare("
    SELECT p.*, u.full_name, u.username, u.email, u.profile_image, u.status AS user_status, t.slug AS template_slug
    FROM portfolios p
    JOIN users u ON p.user_id = u.user_id
    JOIN templates t ON p.template_id = t.template_id
    WHERE p.portfolio_slug = ?
");
$pStmt->execute([$slug]);
$portfolio = $pStmt->fetch();

if (!$portfolio) {
    http_response_code(404);
    $pageTitle = "Portfolio Not Found";
    require_once __DIR__ . '/../includes/header.php';
    echo "<div style='text-align:center; padding: 5rem 1.5rem;'>
            <h1 style='font-size: 2rem; color: var(--secondary-color); margin-bottom: 1rem;'>Portfolio Unavailable</h1>
            <p style='color: var(--text-secondary);'>The portfolio with slug <strong>" . sanitize($slug) . "</strong> does not exist.</p>
            <a href='/' class='nav-btn btn-primary' style='margin-top: 1.5rem; display: inline-block;'>Return to Home</a>
          </div>";
    require_once __DIR__ . '/../includes/footer.php';
    exit();
}

// User status check
if ($portfolio['user_status'] !== 'active') {
    http_response_code(403);
    $pageTitle = "Portfolio Inactive";
    require_once __DIR__ . '/../includes/header.php';
    echo "<div style='text-align:center; padding: 5rem 1.5rem;'>
            <h1 style='font-size: 2rem; color: var(--danger-color); margin-bottom: 1rem;'>Portfolio Temporarily Unavailable</h1>
            <p style='color: var(--text-secondary);'>The user account associated with this portfolio is currently inactive.</p>
            <a href='/' class='nav-btn btn-primary' style='margin-top: 1.5rem; display: inline-block;'>Return to Home</a>
          </div>";
    require_once __DIR__ . '/../includes/footer.php';
    exit();
}

// Published status check (allow preview if requested by logged in owner)
if (!$isPreview && $portfolio['status'] !== 'published') {
    http_response_code(403);
    $pageTitle = "Portfolio Not Published";
    require_once __DIR__ . '/../includes/header.php';
    echo "<div style='text-align:center; padding: 5rem 1.5rem;'>
            <h1 style='font-size: 2rem; color: var(--warning-color); margin-bottom: 1rem;'>Portfolio Draft</h1>
            <p style='color: var(--text-secondary);'>This portfolio is currently not published for public viewing.</p>
            <a href='/' class='nav-btn btn-primary' style='margin-top: 1.5rem; display: inline-block;'>Return to Home</a>
          </div>";
    require_once __DIR__ . '/../includes/footer.php';
    exit();
}

// Record Visit IF public visit (not owner preview)
if (!$isPreview) {
    $vStmt = $pdo->prepare("INSERT INTO portfolio_visits (portfolio_id) VALUES (?)");
    $vStmt->execute([$portfolio['portfolio_id']]);
}

// Fetch visible portfolio sections
$sStmt = $pdo->prepare("SELECT * FROM portfolio_sections WHERE portfolio_id = ? AND is_visible = 1 ORDER BY display_order ASC, section_id ASC");
$sStmt->execute([$portfolio['portfolio_id']]);
$sections = $sStmt->fetchAll();

// Fetch resume
$rStmt = $pdo->prepare("SELECT * FROM resume WHERE portfolio_id = ?");
$rStmt->execute([$portfolio['portfolio_id']]);
$resume = $rStmt->fetch();

// Populate user details for template renderer
$user = [
    'full_name' => $portfolio['full_name'],
    'username' => $portfolio['username'],
    'email' => $portfolio['email'],
    'profile_image' => $portfolio['profile_image']
];

$pageTitle = $portfolio['title'] . " - " . $portfolio['full_name'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= sanitize($pageTitle) ?></title>
    <link rel="stylesheet" href="/assets/css/style.css">
    <link rel="stylesheet" href="/assets/css/templates.css">
</head>
<body>
    <?php if ($isPreview): ?>
        <div style="background-color: #fef3c7; color: #92400e; padding: 0.75rem; text-align: center; font-weight: 600; border-bottom: 1px solid #fde68a;">
            👁️ Owner Preview Mode (This visit does not count toward your public view statistics)
            <a href="/user/dashboard.php" style="margin-left: 1rem; color: #92400e; text-decoration: underline;">Back to Dashboard</a>
        </div>
    <?php endif; ?>

    <?php
    // Load Template Renderer
    $templateFolder = $portfolio['template_slug'] ?? 'modern';
    $templateFile = __DIR__ . "/../templates/{$templateFolder}/view.php";

    if (file_exists($templateFile)) {
        require $templateFile;
    } else {
        require __DIR__ . "/../templates/modern/view.php";
    }
    ?>
</body>
</html>
